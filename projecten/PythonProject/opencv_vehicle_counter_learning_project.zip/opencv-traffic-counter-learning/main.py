"""
OpenCV Vehicle Counter — learning starter

There is deliberately no completed implementation in this project pack.

Start with:
    stages/00_setup.md
    stages/01_video.md

Then implement ONE stage at a time.
"""

from pathlib import Path

VIDEO_PATH = Path("assets/synthetic_traffic.mp4")


def main():
    # STAGE 1:
    # Your first task is only to:
    # - open VIDEO_PATH with OpenCV
    # - prove it opened
    # - read/display frames in a loop
    # - exit when the video ends or you press q
    # - release resources
    #
    # Do not add detection yet.
    pass


if __name__ == "__main__":
    main()
